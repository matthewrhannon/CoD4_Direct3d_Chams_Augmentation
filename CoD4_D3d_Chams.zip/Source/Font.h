//
// D3DFontEngine.h
//
// Copyright � International Coding Team, 2004.
// This file is part of IcT Dx Light (http://ict.bl.am/)
//
// IcT Dx is free software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// IcT Dx is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with IcT Dx; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#ifndef _D3DFONTENGINE_H
#define _D3DFONTENGINE_H

#include "Main.h"

class CFontEngine
{
public:
	CFontEngine( );
	~CFontEngine( );

	HRESULT Initialize( D3DXFONT_DESC dDesc, D3DCOLOR FontColor );
	HRESULT DrawText( char *pString, int x, int y );

	D3DCOLOR		m_FontColor;
	int				m_Align;
	LPD3DXFONT		m_pFont;
	RECT			m_FontRect;
	BOOL			m_bInitialized;
};

#endif