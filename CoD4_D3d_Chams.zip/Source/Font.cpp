//
// D3DFontEngine.cpp
//
// Copyright � International Coding Team, 2004.
// This file is part of IcT Dx Light (http://ict.bl.am/)
//
// IcT Dx is free software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
//
// IcT Dx is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with IcT Dx; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "Font.h"

CFontEngine::CFontEngine( )
{
//	add_log( "CFontEngine Constructing..." );

	m_pFont			= 0;
	m_FontColor		= D3DCOLOR_XRGB( 255, 255, 255 );
	m_bInitialized	= FALSE;
	m_Align			= DT_LEFT | DT_WORDBREAK;

//	add_log( "CFontEngine Constructed" );
}

CFontEngine::~CFontEngine( )
{
	if( m_pFont )
	{
		m_pFont->Release( );
		m_pFont = NULL;
	}
}

HRESULT CFontEngine::Initialize( D3DXFONT_DESC dDesc, D3DCOLOR FontColor )
{
	if( m_pFont )
	{
		m_pFont->Release( );
		m_pFont = NULL;
	}

	D3DXCreateFontIndirect(or_IDirect3DDevice9, &dDesc, &m_pFont );

	m_FontColor = FontColor;

	m_bInitialized = TRUE;

	return S_OK;
}

HRESULT CFontEngine::DrawText( char *pString, int x, int y )
{
	if( !m_bInitialized )
		return E_FAIL;

	HRESULT hRetVal;

	RECT FontRect = { x, y, 0, 0 };

	m_pFont->DrawTextA( NULL, pString, -1, &FontRect, DT_CALCRECT, 0 );
	hRetVal = m_pFont->DrawTextA( NULL, pString, -1, &FontRect, m_Align, m_FontColor );

	return hRetVal;
}