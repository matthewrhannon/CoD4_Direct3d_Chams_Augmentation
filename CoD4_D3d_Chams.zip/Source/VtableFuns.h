//declare the original func and the gate if in windows. syntax is: 
//DEFVFUNC 
//        <name of the var you want to hold the original func>, 
//        <return type>, 
//        <args INCLUDING a pointer to the type of class it is in the beginning> 
DEFVFUNC(engine_CreateEdict, edict_t*, (IVEngineServer* pEngine, int iForceEdictIndex)); 

//just define the func you want to be called instead of the original 
//making sure to include VFUNC between the return type and name 
edict_t* VFUNC mycreateedict(IVEngineServer* pEngine, int iForceEdictIndex){ 
   LOG("Created edict: [%x] [%d]", pEngine, iForceEdictIndex); 

   return engine_CreateEdict(pEngine, iForceEdictIndex); 
} 

your fkn load func { 
//actually hooks the func. syntax is 
//HOOKVFUNC 
//        <a valid pointer to a class with that func in it>, 
//        <the index of it in the vtable (weve been over this)>, 
//        <name of original func var>, 
//        <name of your hook func> 
   HOOKVFUNC(engine, 21, engine_CreateEdict, mycreateedict); 
}