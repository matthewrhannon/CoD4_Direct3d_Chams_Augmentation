#ifndef _D3D9INT_H
#define _D3D9INT_H

extern IDirect3D9 *Handle;
extern IDirect3DDevice9 *or_IDirect3DDevice9;
extern IDirect3DDevice9 *hk_IDirect3DDevice9;

interface hkIDirect3D9 : public IDirect3D9
{
public:
	HRESULT		APIENTRY QueryInterface				(REFIID riid,  void **ppvObj);
	ULONG		APIENTRY AddRef						();
	HRESULT		APIENTRY CheckDepthStencilMatch		(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, D3DFORMAT RenderTargetFormat, D3DFORMAT DepthStencilFormat);
	HRESULT		APIENTRY CheckDeviceFormat			(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, DWORD Usage, D3DRESOURCETYPE RType, D3DFORMAT CheckFormat);
	HRESULT		APIENTRY CheckDeviceFormatConversion(UINT Adapter,D3DDEVTYPE DeviceType,D3DFORMAT SourceFormat,D3DFORMAT TargetFormat);
	HRESULT		APIENTRY CheckDeviceMultiSampleType	(UINT Adapter,D3DDEVTYPE DeviceType,D3DFORMAT SurfaceFormat,BOOL Windowed,D3DMULTISAMPLE_TYPE MultiSampleType,DWORD* pQualityLevels);
	HRESULT		APIENTRY CheckDeviceType			(UINT Adapter, D3DDEVTYPE CheckType, D3DFORMAT DisplayFormat, D3DFORMAT BackBufferFormat, BOOL Windowed);
	HRESULT		APIENTRY CreateDevice				(UINT Adapter, D3DDEVTYPE DeviceType, HWND hFocusWindow, DWORD BehaviorFlags, D3DPRESENT_PARAMETERS *pPresentationParameters, IDirect3DDevice9 **ppReturnedDeviceInterface);
	HRESULT		APIENTRY EnumAdapterModes			(UINT Adapter,D3DFORMAT Format,UINT Mode,D3DDISPLAYMODE* pMode);
	UINT		APIENTRY GetAdapterCount			();
	HRESULT		APIENTRY GetAdapterDisplayMode		(UINT Adapter, D3DDISPLAYMODE *pMode);
	HRESULT		APIENTRY GetAdapterIdentifier		(UINT Adapter, DWORD Flags, D3DADAPTER_IDENTIFIER9 *pIdentifier);
	UINT		APIENTRY GetAdapterModeCount		(UINT Adapter,D3DFORMAT Format);
	HMONITOR	APIENTRY GetAdapterMonitor			(UINT Adapter);
	HRESULT		APIENTRY GetDeviceCaps				(UINT Adapter, D3DDEVTYPE DeviceType, D3DCAPS9 *pCaps);
	HRESULT		APIENTRY RegisterSoftwareDevice		(void *pInitializeFunction);
	ULONG		APIENTRY Release					();
};

interface hkIDirect3DDevice9 : public IDirect3DDevice9
{
public:
	HRESULT		APIENTRY QueryInterface(REFIID riid, void** ppvObj);
    ULONG		APIENTRY AddRef();
    ULONG		APIENTRY Release();
    HRESULT		APIENTRY TestCooperativeLevel();
    UINT		APIENTRY GetAvailableTextureMem();
    HRESULT		APIENTRY EvictManagedResources();
    HRESULT		APIENTRY GetDirect3D(IDirect3D9** ppD3D9);
    HRESULT		APIENTRY GetDeviceCaps(D3DCAPS9* pCaps);
    HRESULT		APIENTRY GetDisplayMode(UINT iSwapChain,D3DDISPLAYMODE* pMode);
    HRESULT		APIENTRY GetCreationParameters(D3DDEVICE_CREATION_PARAMETERS *pParameters);
    HRESULT		APIENTRY SetCursorProperties(UINT XHotSpot,UINT YHotSpot,IDirect3DSurface9* pCursorBitmap);
    void		APIENTRY SetCursorPosition(int X,int Y,DWORD Flags);
    BOOL		APIENTRY ShowCursor(BOOL bShow);
    HRESULT		APIENTRY CreateAdditionalSwapChain(D3DPRESENT_PARAMETERS* pPresentationParameters,IDirect3DSwapChain9** pSwapChain);
    HRESULT		APIENTRY GetSwapChain(UINT iSwapChain,IDirect3DSwapChain9** pSwapChain);
    UINT		APIENTRY GetNumberOfSwapChains();
    HRESULT		APIENTRY Reset(D3DPRESENT_PARAMETERS* pPresentationParameters);
    HRESULT		APIENTRY Present(CONST RECT* pSourceRect,CONST RECT* pDestRect,HWND hDestWindowOverride,CONST RGNDATA* pDirtyRegion);
    HRESULT		APIENTRY GetBackBuffer(UINT iSwapChain,UINT iBackBuffer,D3DBACKBUFFER_TYPE Type,IDirect3DSurface9** ppBackBuffer);
    HRESULT		APIENTRY GetRasterStatus(UINT iSwapChain,D3DRASTER_STATUS* pRasterStatus);
    HRESULT		APIENTRY SetDialogBoxMode(BOOL bEnableDialogs);
    void		APIENTRY SetGammaRamp(UINT iSwapChain,DWORD Flags,CONST D3DGAMMARAMP* pRamp);
    void		APIENTRY GetGammaRamp(UINT iSwapChain,D3DGAMMARAMP* pRamp);
    HRESULT		APIENTRY CreateTexture(UINT Width,UINT Height,UINT Levels,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DTexture9** ppTexture,HANDLE* pSharedHandle);
    HRESULT		APIENTRY CreateVolumeTexture(UINT Width,UINT Height,UINT Depth,UINT Levels,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DVolumeTexture9** ppVolumeTexture,HANDLE* pSharedHandle);
    HRESULT		APIENTRY CreateCubeTexture(UINT EdgeLength,UINT Levels,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DCubeTexture9** ppCubeTexture,HANDLE* pSharedHandle);
    HRESULT		APIENTRY CreateVertexBuffer(UINT Length,DWORD Usage,DWORD FVF,D3DPOOL Pool,IDirect3DVertexBuffer9** ppVertexBuffer,HANDLE* pSharedHandle);
    HRESULT		APIENTRY CreateIndexBuffer(UINT Length,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DIndexBuffer9** ppIndexBuffer,HANDLE* pSharedHandle);
    HRESULT		APIENTRY CreateRenderTarget(UINT Width,UINT Height,D3DFORMAT Format,D3DMULTISAMPLE_TYPE MultiSample,DWORD MultisampleQuality,BOOL Lockable,IDirect3DSurface9** ppSurface,HANDLE* pSharedHandle);
    HRESULT		APIENTRY CreateDepthStencilSurface(UINT Width,UINT Height,D3DFORMAT Format,D3DMULTISAMPLE_TYPE MultiSample,DWORD MultisampleQuality,BOOL Discard,IDirect3DSurface9** ppSurface,HANDLE* pSharedHandle);
    HRESULT		APIENTRY UpdateSurface(IDirect3DSurface9* pSourceSurface,CONST RECT* pSourceRect,IDirect3DSurface9* pDestinationSurface,CONST POINT* pDestPoint);
    HRESULT		APIENTRY UpdateTexture(IDirect3DBaseTexture9* pSourceTexture,IDirect3DBaseTexture9* pDestinationTexture);
    HRESULT		APIENTRY GetRenderTargetData(IDirect3DSurface9* pRenderTarget,IDirect3DSurface9* pDestSurface);
    HRESULT		APIENTRY GetFrontBufferData(UINT iSwapChain,IDirect3DSurface9* pDestSurface);
    HRESULT		APIENTRY StretchRect(IDirect3DSurface9* pSourceSurface,CONST RECT* pSourceRect,IDirect3DSurface9* pDestSurface,CONST RECT* pDestRect,D3DTEXTUREFILTERTYPE Filter);
    HRESULT		APIENTRY ColorFill(IDirect3DSurface9* pSurface,CONST RECT* pRect,D3DCOLOR color);
    HRESULT		APIENTRY CreateOffscreenPlainSurface(UINT Width,UINT Height,D3DFORMAT Format,D3DPOOL Pool,IDirect3DSurface9** ppSurface,HANDLE* pSharedHandle);
    HRESULT		APIENTRY SetRenderTarget(DWORD RenderTargetIndex,IDirect3DSurface9* pRenderTarget);
    HRESULT		APIENTRY GetRenderTarget(DWORD RenderTargetIndex,IDirect3DSurface9** ppRenderTarget);
    HRESULT		APIENTRY SetDepthStencilSurface(IDirect3DSurface9* pNewZStencil);
    HRESULT		APIENTRY GetDepthStencilSurface(IDirect3DSurface9** ppZStencilSurface);
    HRESULT		APIENTRY BeginScene();
    HRESULT		APIENTRY EndScene();
    HRESULT		APIENTRY Clear(DWORD Count,CONST D3DRECT* pRects,DWORD Flags,D3DCOLOR Color,float Z,DWORD Stencil);
    HRESULT		APIENTRY SetTransform(D3DTRANSFORMSTATETYPE State,CONST D3DMATRIX* pMatrix);
    HRESULT		APIENTRY GetTransform(D3DTRANSFORMSTATETYPE State,D3DMATRIX* pMatrix);
    HRESULT		APIENTRY MultiplyTransform(D3DTRANSFORMSTATETYPE,CONST D3DMATRIX*);
    HRESULT		APIENTRY SetViewport(CONST D3DVIEWPORT9* pViewport);
    HRESULT		APIENTRY GetViewport(D3DVIEWPORT9* pViewport);
    HRESULT		APIENTRY SetMaterial(CONST D3DMATERIAL9* pMaterial);
    HRESULT		APIENTRY GetMaterial(D3DMATERIAL9* pMaterial);
    HRESULT		APIENTRY SetLight(DWORD Index,CONST D3DLIGHT9*);
    HRESULT		APIENTRY GetLight(DWORD Index,D3DLIGHT9*);
    HRESULT		APIENTRY LightEnable(DWORD Index,BOOL Enable);
    HRESULT		APIENTRY GetLightEnable(DWORD Index,BOOL* pEnable);
    HRESULT		APIENTRY SetClipPlane(DWORD Index,CONST float* pPlane);
    HRESULT		APIENTRY GetClipPlane(DWORD Index,float* pPlane);
    HRESULT		APIENTRY SetRenderState(D3DRENDERSTATETYPE State,DWORD Value);
    HRESULT		APIENTRY GetRenderState(D3DRENDERSTATETYPE State,DWORD* pValue);
    HRESULT		APIENTRY CreateStateBlock(D3DSTATEBLOCKTYPE Type,IDirect3DStateBlock9** ppSB);
    HRESULT		APIENTRY BeginStateBlock();
    HRESULT		APIENTRY EndStateBlock(IDirect3DStateBlock9** ppSB);
    HRESULT		APIENTRY SetClipStatus(CONST D3DCLIPSTATUS9* pClipStatus);
    HRESULT		APIENTRY GetClipStatus(D3DCLIPSTATUS9* pClipStatus);
    HRESULT		APIENTRY GetTexture(DWORD Stage,IDirect3DBaseTexture9** ppTexture);
    HRESULT		APIENTRY SetTexture(DWORD Stage,IDirect3DBaseTexture9* pTexture);
    HRESULT		APIENTRY GetTextureStageState(DWORD Stage,D3DTEXTURESTAGESTATETYPE Type,DWORD* pValue);
    HRESULT		APIENTRY SetTextureStageState(DWORD Stage,D3DTEXTURESTAGESTATETYPE Type,DWORD Value);
    HRESULT		APIENTRY GetSamplerState(DWORD Sampler,D3DSAMPLERSTATETYPE Type,DWORD* pValue);
    HRESULT		APIENTRY SetSamplerState(DWORD Sampler,D3DSAMPLERSTATETYPE Type,DWORD Value);
    HRESULT		APIENTRY ValidateDevice(DWORD* pNumPasses);
    HRESULT		APIENTRY SetPaletteEntries(UINT PaletteNumber,CONST PALETTEENTRY* pEntries);
    HRESULT		APIENTRY GetPaletteEntries(UINT PaletteNumber,PALETTEENTRY* pEntries);
    HRESULT		APIENTRY SetCurrentTexturePalette(UINT PaletteNumber);
    HRESULT		APIENTRY GetCurrentTexturePalette(UINT *PaletteNumber);
    HRESULT		APIENTRY SetScissorRect(CONST RECT* pRect);
    HRESULT		APIENTRY GetScissorRect(RECT* pRect);
    HRESULT		APIENTRY SetSoftwareVertexProcessing(BOOL bSoftware);
    BOOL		APIENTRY GetSoftwareVertexProcessing();
    HRESULT		APIENTRY SetNPatchMode(float nSegments);
    float		APIENTRY GetNPatchMode();
    HRESULT		APIENTRY DrawPrimitive(D3DPRIMITIVETYPE PrimitiveType,UINT StartVertex,UINT PrimitiveCount);
    HRESULT		APIENTRY DrawIndexedPrimitive(D3DPRIMITIVETYPE,INT BaseVertexIndex,UINT MinVertexIndex,UINT NumVertices,UINT startIndex,UINT primCount);
    HRESULT		APIENTRY DrawPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType,UINT PrimitiveCount,CONST void* pVertexStreamZeroData,UINT VertexStreamZeroStride);
    HRESULT		APIENTRY DrawIndexedPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType,UINT MinVertexIndex,UINT NumVertices,UINT PrimitiveCount,CONST void* pIndexData,D3DFORMAT IndexDataFormat,CONST void* pVertexStreamZeroData,UINT VertexStreamZeroStride);
    HRESULT		APIENTRY ProcessVertices(UINT SrcStartIndex,UINT DestIndex,UINT VertexCount,IDirect3DVertexBuffer9* pDestBuffer,IDirect3DVertexDeclaration9* pVertexDecl,DWORD Flags);
    HRESULT		APIENTRY CreateVertexDeclaration(CONST D3DVERTEXELEMENT9* pVertexElements,IDirect3DVertexDeclaration9** ppDecl);
    HRESULT		APIENTRY SetVertexDeclaration(IDirect3DVertexDeclaration9* pDecl);
    HRESULT		APIENTRY GetVertexDeclaration(IDirect3DVertexDeclaration9** ppDecl);
    HRESULT		APIENTRY SetFVF(DWORD FVF);
    HRESULT		APIENTRY GetFVF(DWORD* pFVF);
    HRESULT		APIENTRY CreateVertexShader(CONST DWORD* pFunction,IDirect3DVertexShader9** ppShader);
    HRESULT		APIENTRY SetVertexShader(IDirect3DVertexShader9* pShader);
    HRESULT		APIENTRY GetVertexShader(IDirect3DVertexShader9** ppShader);
    HRESULT		APIENTRY SetVertexShaderConstantF(UINT StartRegister,CONST float* pConstantData,UINT Vector4fCount);
    HRESULT		APIENTRY GetVertexShaderConstantF(UINT StartRegister,float* pConstantData,UINT Vector4fCount);
    HRESULT		APIENTRY SetVertexShaderConstantI(UINT StartRegister,CONST int* pConstantData,UINT Vector4iCount);
    HRESULT		APIENTRY GetVertexShaderConstantI(UINT StartRegister,int* pConstantData,UINT Vector4iCount);
    HRESULT		APIENTRY SetVertexShaderConstantB(UINT StartRegister,CONST BOOL* pConstantData,UINT  BoolCount);
    HRESULT		APIENTRY GetVertexShaderConstantB(UINT StartRegister,BOOL* pConstantData,UINT BoolCount);
    HRESULT		APIENTRY SetStreamSource(UINT StreamNumber,IDirect3DVertexBuffer9* pStreamData,UINT OffsetInBytes,UINT Stride);
    HRESULT		APIENTRY GetStreamSource(UINT StreamNumber,IDirect3DVertexBuffer9** ppStreamData,UINT* OffsetInBytes,UINT* pStride);
    HRESULT		APIENTRY SetStreamSourceFreq(UINT StreamNumber,UINT Divider);
    HRESULT		APIENTRY GetStreamSourceFreq(UINT StreamNumber,UINT* Divider);
    HRESULT		APIENTRY SetIndices(IDirect3DIndexBuffer9* pIndexData);
    HRESULT		APIENTRY GetIndices(IDirect3DIndexBuffer9** ppIndexData);
    HRESULT		APIENTRY CreatePixelShader(CONST DWORD* pFunction,IDirect3DPixelShader9** ppShader);
    HRESULT		APIENTRY SetPixelShader(IDirect3DPixelShader9* pShader);
    HRESULT		APIENTRY GetPixelShader(IDirect3DPixelShader9** ppShader);
    HRESULT		APIENTRY SetPixelShaderConstantF(UINT StartRegister,CONST float* pConstantData,UINT Vector4fCount);
    HRESULT		APIENTRY GetPixelShaderConstantF(UINT StartRegister,float* pConstantData,UINT Vector4fCount);
    HRESULT		APIENTRY SetPixelShaderConstantI(UINT StartRegister,CONST int* pConstantData,UINT Vector4iCount);
    HRESULT		APIENTRY GetPixelShaderConstantI(UINT StartRegister,int* pConstantData,UINT Vector4iCount);
    HRESULT		APIENTRY SetPixelShaderConstantB(UINT StartRegister,CONST BOOL* pConstantData,UINT  BoolCount);
    HRESULT		APIENTRY GetPixelShaderConstantB(UINT StartRegister,BOOL* pConstantData,UINT BoolCount);
    HRESULT		APIENTRY DrawRectPatch(UINT Handle,CONST float* pNumSegs,CONST D3DRECTPATCH_INFO* pRectPatchInfo);
    HRESULT		APIENTRY DrawTriPatch(UINT Handle,CONST float* pNumSegs,CONST D3DTRIPATCH_INFO* pTriPatchInfo);
    HRESULT		APIENTRY DeletePatch(UINT Handle);
    HRESULT		APIENTRY CreateQuery(D3DQUERYTYPE Type,IDirect3DQuery9** ppQuery);
};


//--------------------------------- Texture

interface hkIDirect3DTexture9 : public IDirect3DTexture9
{
public:
	struct
	{
		DWORD crc32;
		UINT width;
		UINT height;
		UINT levels;
		D3DFORMAT format;
		IDirect3DTexture9 *orTexture;
		int numTexture;
	}Texture;

	IDirect3DTexture9		*pTexture9;
	DWORD					m_dwSizeData;
	IDirect3DTexture9		*pD3DTexture9;
	GUID id;
	D3DLOCKED_RECT			*m_rectBackup;

	HRESULT					APIENTRY QueryInterface			(REFIID iid, void ** ppvObject);
	ULONG					APIENTRY AddRef					();
	ULONG					APIENTRY Release				();

	HRESULT					APIENTRY GetDevice				(IDirect3DDevice9 **ppDevice);
	HRESULT					APIENTRY SetPrivateData			(REFGUID refguid,CONST void* pData,DWORD SizeOfData,DWORD Flags);
	HRESULT					APIENTRY GetPrivateData			(REFGUID refguid,void* pData,DWORD* pSizeOfData);
	HRESULT					APIENTRY FreePrivateData		(REFGUID refguid);
	DWORD					APIENTRY SetPriority			(DWORD PriorityNew);
	DWORD					APIENTRY GetPriority			();
	void					APIENTRY PreLoad				();
	D3DRESOURCETYPE			APIENTRY GetType				();
	DWORD					APIENTRY SetLOD					(DWORD LODNew);
	DWORD					APIENTRY GetLOD					();
	DWORD					APIENTRY GetLevelCount			();
	HRESULT					APIENTRY SetAutoGenFilterType	(D3DTEXTUREFILTERTYPE FilterType);
	D3DTEXTUREFILTERTYPE	APIENTRY GetAutoGenFilterType	();
	void					APIENTRY GenerateMipSubLevels	();
	HRESULT					APIENTRY GetLevelDesc			(UINT Level,D3DSURFACE_DESC *pDesc);
	HRESULT					APIENTRY GetSurfaceLevel		(UINT Level,IDirect3DSurface9** ppSurfaceLevel);
	HRESULT					APIENTRY LockRect				(UINT Level,D3DLOCKED_RECT* pLockedRect,CONST RECT* pRect,DWORD Flags);
	HRESULT					APIENTRY UnlockRect				(UINT Level);
	HRESULT					APIENTRY AddDirtyRect			(CONST RECT* pDirtyRect);

	#ifdef D3D_DEBUG_INFO
    LPCWSTR Name;
    UINT Width;
    UINT Height;
    UINT Levels;
    DWORD Usage;
    D3DFORMAT Format;
    D3DPOOL Pool;
    DWORD Priority;
    DWORD LOD;
    D3DTEXTUREFILTERTYPE FilterType;
    UINT LockCount;
    LPCWSTR CreationCallStack;
	#endif
};

interface hkIDirectDraw : public IDirectDraw
{
public:
    /*** IUnknown methods ***/
	HRESULT __stdcall QueryInterface(REFIID riid, void ** ppvObject);
	ULONG __stdcall AddRef();
	ULONG __stdcall Release();

    /*** IDirectDraw methods ***/
	HRESULT __stdcall Compact();
	HRESULT __stdcall CreateClipper(DWORD a, LPDIRECTDRAWCLIPPER FAR* b, IUnknown FAR * c);
	HRESULT __stdcall CreatePalette(DWORD a, LPPALETTEENTRY b, LPDIRECTDRAWPALETTE FAR* c, IUnknown FAR * d);
	HRESULT __stdcall CreateSurface(LPDDSURFACEDESC a, LPDIRECTDRAWSURFACE FAR *b, IUnknown FAR *c);
	HRESULT __stdcall DuplicateSurface(LPDIRECTDRAWSURFACE a, LPDIRECTDRAWSURFACE FAR * b);
	HRESULT __stdcall EnumDisplayModes(DWORD a, LPDDSURFACEDESC, LPVOID b, LPDDENUMMODESCALLBACK c);
	HRESULT __stdcall EnumSurfaces(DWORD a, LPDDSURFACEDESC b, LPVOID,LPDDENUMSURFACESCALLBACK c);
	HRESULT __stdcall FlipToGDISurface();
	HRESULT __stdcall GetCaps(LPDDCAPS a, LPDDCAPS b);
	HRESULT __stdcall GetDisplayMode(LPDDSURFACEDESC a);	
	HRESULT __stdcall GetFourCCCodes(LPDWORD a, LPDWORD b);
	HRESULT __stdcall GetGDISurface(LPDIRECTDRAWSURFACE FAR * a);
	HRESULT __stdcall GetMonitorFrequency(LPDWORD a);
	HRESULT __stdcall GetScanLine(LPDWORD a);
	HRESULT __stdcall GetVerticalBlankStatus(LPBOOL a);
	HRESULT __stdcall Initialize(GUID FAR * a);
	HRESULT __stdcall RestoreDisplayMode();			
	HRESULT __stdcall SetCooperativeLevel(HWND a, DWORD b);
	HRESULT __stdcall SetDisplayMode(DWORD a, DWORD b,DWORD c);
	HRESULT __stdcall WaitForVerticalBlank(DWORD a, HANDLE b);

	IDirectDraw *cur_DirectDraw;
};

#endif