//Matt Hannon Nov 06 07

#include "Main.h"
#include "Direct3DFunctions.h"

fn_Direct3DCreate9 or_Direct3DCreate9, or1_Direct3DCreate9 = NULL;;
InternalDDC or_ddc = NULL;

char g_Buffer[256];
hkIDirect3D9 *hk_Direct3D9 = NULL; 

IDirect3D9 *Handle = NULL;
FILE *LogFile = NULL;

HANDLE hLoadThread = NULL;

MODULEINFO modInfo;

void Log(char *Msg, ...)
{
	//Test if Log exists once
	static bool Once = false;
	static char curDirectory[128];

	if(!Once)
	{
		Once = true;
		GetCurrentDirectory(128, &curDirectory[0]);

		sprintf(g_Buffer, "%s\\Log.txt", curDirectory);
		FILE *fExist = NULL;
		fExist = fopen(g_Buffer, "r+");
		if(fExist)
		{
			fclose(fExist);
			remove(g_Buffer);
		}
	}

	va_list List;
	static char Temp[256];

	va_start(List, Msg);
		vsprintf(Temp, Msg, List);
	va_end(List);

	FILE *fLog = NULL;
	sprintf(g_Buffer, "%s\\Log.txt", curDirectory);
	fLog = fopen(g_Buffer, "a+");
	
	if(!fLog)
	{
		MessageBox(HWND_DESKTOP, "Error creating log file", "Error", MB_OK);
		return;
	}

	//Write it!
	fputs(Temp, fLog);
	fputc('\n', fLog);

	fclose(fLog);
};

__declspec(naked) void Overwrite(void) 
{
	__asm
	{
		mov edi, edi
		push ebp
		mov ebp, esp
	}
}

IDirect3D9 *APIENTRY hk_Direct3dCreate9(UINT SDKVersion)
{
	Log("Actually IN HK");

	static IDirect3D9 *HookReturn;
	HookReturn = new hkIDirect3D9;

	Handle = or1_Direct3DCreate9(SDKVersion);
	if(!Handle)
	{
		Log("Error: Handle = %0x", Handle);
		return Handle;
	}

	Log("Orignal direct3d handle: %0x", Handle);
	Log("Hooked direct3d handle 0x%x", HookReturn);

	

	return HookReturn;
}


int __cdecl hk_ddc(int a, IDirectDraw *b, int c, int d, int e)
{
	//Make sure coming from PBCL
	
	Log("In hooked DDC");

	static hkIDirectDraw *hk_DirectDraw, *temp_ddc;
	temp_ddc = new hkIDirectDraw; 

	Log("B/IDirectDraw = 0x%x", *b);

	int ret = or_ddc(a, temp_ddc->cur_DirectDraw, c, d, e);
	
	//hk_DirectDraw = (hkIDirectDraw *)VirtualAlloc(GetModuleHandle("pbcll.dll"), sizeof(hkIDirectDraw), MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	DWORD old;
	
	//VirtualProtect((void *)0x17828744, sizeof(IDirectDraw), PAGE_EXECUTE_READWRITE, &old);
	//memcpy((void *)hk_DirectDraw, (void *)temp_ddc, sizeof(hkIDirectDraw));
//	memcpy((void *)0x17828744, (void *)temp_ddc, sizeof(IDirectDraw));
	//VirtualProtect((void *)0x17828744, sizeof(IDirectDraw), old, NULL);

	VirtualProtect((void *)b, sizeof(IDirectDraw), PAGE_EXECUTE_READWRITE, &old);	
	memcpy((void *)b, (void *)temp_ddc, sizeof(IDirectDraw));
	VirtualProtect((void *)b, sizeof(IDirectDraw), old, NULL);
	
	Log("hooked B/IDirectDraw = 0x%x", *b);

	hackOn = false;

	return ret;
};

/*
bool HookFunction(BYTE *Hook, BYTE *Dest)
{
	DWORD OldProtection = NULL;

	VirtualProtect(Dest, 0x5, PAGE_EXECUTE_READWRITE, &OldProtection);
	Dest[4] = 0xE9;
	Dest--;
	*(DWORD *)Dest = (DWORD)&Hook;
	VirtualProtect(Dest, 0x5, OldProtection, NULL);

	Log("Hook Function address : %0x", HookFunction);

//8B FF 55 8B EC   - opcodes for overwrite stuff

	return false;
}
*/


DWORD WINAPI InitalizeThread(LPVOID Parameter)
{
	//__asm int 3

	HMODULE hDirect3DLib = NULL;
	while(!hDirect3DLib)
	{
		hDirect3DLib = GetModuleHandle("d3d9.dll");
		Sleep(10);
	} //DLL is loaded into address space

	if(!hDirect3DLib)
	{
		Log("Handle for d3d9 invalid - %0x", *hDirect3DLib);
		return 1;
	}

	if(hDirect3DLib == 0)
		Log("It really is equal to 0");

	Log("Handle for hDirect3DLib: 0x%08lX", *hDirect3DLib);
	
	or_Direct3DCreate9 =  (fn_Direct3DCreate9)GetProcAddress(hDirect3DLib, "Direct3DCreate9");

	if(!or_Direct3DCreate9)
	{
		Log("Handle for Direct3DCreate9 invalid - %0x", *or_Direct3DCreate9);
		return 1;
	}

	Log("Address of Direct3DCreate9 = 0x%08lX", *or_Direct3DCreate9);

	if(or1_Direct3DCreate9 == NULL)
		Log("Its equal to null still, good");

	or1_Direct3DCreate9 = (fn_Direct3DCreate9)DetourFunc(( BYTE* )GetProcAddress( LoadLibrary( "d3d9.dll" ), "Direct3DCreate9" ), (BYTE *)hk_Direct3dCreate9, 5);

	Log("or1_Direct3DCreate9: 0x%08lX", (DWORD *)&or1_Direct3DCreate9);
	Log("or_Direct3DCreate9: 0x%08lX", (DWORD *)&or_Direct3DCreate9);
	Log("hk_Direct3DCreate9: 0x%08lX", (DWORD *)&hk_Direct3dCreate9);

	if(!or_Direct3DCreate9)
	{
		Log("Unable to hook Direct3dCreate9");
		return 1;
	}

	//PB_SS stuff
	HMODULE hDraw = LoadLibrary("ddraw.dll");
	try
	{
		or_ddc = (InternalDDC)DetourFunc(( BYTE* )0x7377F139 , (BYTE *)hk_ddc, 5);
	}
	catch(...)
	{
		Log("3 execption");
	}

	if(GetModuleInformation((HANDLE)GetCurrentProcess(), GetModuleHandle("pbcl.dll"), &modInfo, sizeof(MODULEINFO)))
	{
		Log("PBCL BaseDll: 0x%x", modInfo.lpBaseOfDll);
		Log("PBCL sizedll 0x%x", modInfo.SizeOfImage);
	}

	/*
	try
	{
	or_ddc = (InternalDDC)DetourFunc(( BYTE* )(hDraw - 0x77F139), (BYTE *)hk_ddc, 5);
	}
	catch(...)
	{
		Log("1 expection");
	}
	if(or_ddc)
		Log("Succeed in hooking - 1");
	else 
	{
		try
		{
		or_ddc = (InternalDDC)DetourFunc(( BYTE* )(hDraw + 0x77F139), (BYTE *)hk_ddc, 5);
		}
		catch(...)
		{
			Log("2 excetpion");
		}
		if(or_ddc)
			Log("succceed again");
		else
		{
			try
			{
			or_ddc = (InternalDDC)DetourFunc(( BYTE* )0x7377F139 , (BYTE *)hk_ddc, 5);
			}
			catch(...)
			{
				Log("3 execption");
			}

			if(!or_ddc)
				Log("Didnt succceed woo this sucks");
		}
	}
	*/
	if(or_ddc)
		Log("Succeeded overal in hook");

			
//	77F139
	return 1;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		{		
			DisableThreadLibraryCalls(hModule);
			MessageBox(HWND_DESKTOP, "Entering DLL", "Peace", MB_OK);
			
			//Make into a thread! MORON
			hLoadThread = CreateThread(NULL, 0, InitalizeThread, NULL, NULL, NULL);
			if(!hLoadThread)
			{
				MessageBox(HWND_DESKTOP, "Error creating start thread", "Error", MB_OK);
				return 1;
			}

			break;
		}
		case DLL_PROCESS_DETACH:
		{
			Log("Exiting....");

			CloseHandle(hLoadThread);
		}
		default:
			break;
	}	

	return TRUE;
}