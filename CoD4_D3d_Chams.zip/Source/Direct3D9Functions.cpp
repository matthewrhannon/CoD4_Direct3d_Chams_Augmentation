#include "Main.h"

DWORD timer = 0;
DWORD start = 0;

HWND hMainWindow = NULL;
bool hackOn = true;
//RED
const BYTE bRed[60] =
{
    0x42, 0x4D, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
    0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x12, 0x0B, 0x00, 0x00, 0x12, 0x0B, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0xFF, 0x00, 0x00, 0x00
};

const BYTE bBlue[60] =
{
    0x42, 0x4D, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
    0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x12, 0x0B, 0x00, 0x00, 0x12, 0x0B, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0xFF, 0x00, 0x00, 0x00, 0x00, 0x00
}; 

const BYTE bGreen[60] =
{
	0x42, 0x4D, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 
	0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 
	0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x06, 0x00, 
	0x00, 0x00, 0x12, 0x0B, 0x00, 0x00, 0x12, 0x0B, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x9E, 0x00, 0x00, 0x00, 0x00
};

const BYTE bYellow[60] =
{
	0x42, 0x4D, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 
	0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 
	0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 
	0x00, 0x00, 0x12, 0x0B, 0x00, 0x00, 0x12, 0x0B, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0xFF, 0xFF, 0x00, 0x00, 0x00
};

LPDIRECT3DTEXTURE9    texRed;
LPDIRECT3DTEXTURE9    texBlue;
LPDIRECT3DTEXTURE9    texGreen;
LPDIRECT3DTEXTURE9    texYellow;

//Font
CFontEngine *pFont = NULL;

//Device
IDirect3DDevice9 *or_IDirect3DDevice9 = NULL;
IDirect3DDevice9 *hk_IDirect3DDevice9 = NULL;

hkIDirect3DTexture9 *cur_texture;
int g_numTextures = 0;
int g_numTexture = 0;

HRESULT APIENTRY hkIDirect3D9::QueryInterface(REFIID riid,  void **ppvObj)
{
	return Handle->QueryInterface(riid,  ppvObj);
}

ULONG APIENTRY hkIDirect3D9::AddRef()
{
	return Handle->AddRef();
}

HRESULT APIENTRY hkIDirect3D9::CheckDepthStencilMatch(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, D3DFORMAT RenderTargetFormat, D3DFORMAT DepthStencilFormat)
{
	return Handle->CheckDepthStencilMatch(Adapter, DeviceType, AdapterFormat, RenderTargetFormat, DepthStencilFormat);
}

HRESULT APIENTRY hkIDirect3D9::CheckDeviceFormat(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, DWORD Usage, D3DRESOURCETYPE RType, D3DFORMAT CheckFormat)
{
	return Handle->CheckDeviceFormat(Adapter, DeviceType, AdapterFormat, Usage, RType, CheckFormat);
}

HRESULT APIENTRY hkIDirect3D9::CheckDeviceFormatConversion(UINT Adapter,D3DDEVTYPE DeviceType,D3DFORMAT SourceFormat,D3DFORMAT TargetFormat)
{
	return Handle->CheckDeviceFormatConversion(Adapter, DeviceType, SourceFormat, TargetFormat);
}

HRESULT APIENTRY hkIDirect3D9::CheckDeviceMultiSampleType(UINT Adapter,D3DDEVTYPE DeviceType,D3DFORMAT SurfaceFormat,BOOL Windowed,D3DMULTISAMPLE_TYPE MultiSampleType,DWORD* pQualityLevels)
{
	return Handle->CheckDeviceMultiSampleType(Adapter, DeviceType, SurfaceFormat, Windowed, MultiSampleType, pQualityLevels);
}

HRESULT APIENTRY hkIDirect3D9::CheckDeviceType(UINT Adapter, D3DDEVTYPE CheckType, D3DFORMAT DisplayFormat, D3DFORMAT BackBufferFormat, BOOL Windowed)
{
	return Handle->CheckDeviceType(Adapter, CheckType, DisplayFormat, BackBufferFormat, Windowed);
}

HRESULT APIENTRY hkIDirect3D9::CreateDevice(UINT Adapter, D3DDEVTYPE DeviceType, HWND hFocusWindow, DWORD BehaviorFlags, D3DPRESENT_PARAMETERS *pPresentationParameters, IDirect3DDevice9 **ppReturnedDeviceInterface)
{
	Log("In createdrive");
	
	if(!hk_IDirect3DDevice9)
		hk_IDirect3DDevice9 = new hkIDirect3DDevice9;

	//pPresentationParameters->Windowed = true;
	HRESULT hRet = Handle->CreateDevice( Adapter, DeviceType, hFocusWindow, BehaviorFlags, pPresentationParameters, ppReturnedDeviceInterface );
	hMainWindow = pPresentationParameters->hDeviceWindow;

	or_IDirect3DDevice9 = *ppReturnedDeviceInterface;
	*ppReturnedDeviceInterface = hk_IDirect3DDevice9;

	D3DXCreateTextureFromFileInMemory(or_IDirect3DDevice9, ( LPCVOID )&bRed, 60,  &texRed);
	D3DXCreateTextureFromFileInMemory(or_IDirect3DDevice9, ( LPCVOID )&bBlue, 60,  &texBlue); 
	D3DXCreateTextureFromFileInMemory( or_IDirect3DDevice9, ( LPCVOID )&bGreen, 60,  &texGreen	); 
	D3DXCreateTextureFromFileInMemory( or_IDirect3DDevice9, ( LPCVOID )&bYellow, 60,  &texYellow);

	return hRet;
}

HRESULT APIENTRY hkIDirect3D9::EnumAdapterModes(UINT Adapter,D3DFORMAT Format,UINT Mode,D3DDISPLAYMODE* pMode)
{
	return Handle->EnumAdapterModes(Adapter, Format, Mode, pMode);
}

UINT APIENTRY hkIDirect3D9::GetAdapterCount()
{
	return Handle->GetAdapterCount();
}

HRESULT APIENTRY hkIDirect3D9::GetAdapterDisplayMode(UINT Adapter, D3DDISPLAYMODE *pMode)
{
	return Handle->GetAdapterDisplayMode(Adapter, pMode);
}

HRESULT APIENTRY hkIDirect3D9::GetAdapterIdentifier(UINT Adapter, DWORD Flags, D3DADAPTER_IDENTIFIER9 *pIdentifier)
{
	return Handle->GetAdapterIdentifier(Adapter, Flags, pIdentifier);
}

UINT APIENTRY hkIDirect3D9::GetAdapterModeCount(UINT Adapter,D3DFORMAT Format)
{
	return Handle->GetAdapterModeCount(Adapter, Format);
}

HMONITOR APIENTRY hkIDirect3D9::GetAdapterMonitor(UINT Adapter)
{
	return Handle->GetAdapterMonitor(Adapter);
}

HRESULT APIENTRY hkIDirect3D9::GetDeviceCaps(UINT Adapter, D3DDEVTYPE DeviceType, D3DCAPS9 *pCaps)
{
/* Justin's issue
	D3DCAPS9 caps;

	if(pCaps->AlphaCmpCaps == D3DPCMPCAPS_ALWAYS || D3DPCMPCAPS_NEVER)
	{
		Log("Mine doesnt supporti t!");
		pCaps->AlphaCmpCaps = 0x50;
	}
	__asm int 3;
*/
	Log("Called Get Device Caps");
	
	return Handle->GetDeviceCaps(Adapter, DeviceType, pCaps);
}

HRESULT APIENTRY hkIDirect3D9::RegisterSoftwareDevice(void *pInitializeFunction)
{
	return Handle->RegisterSoftwareDevice(pInitializeFunction);
}

ULONG APIENTRY hkIDirect3D9::Release()
{
	Log("Releasing direct9 ");
	Handle->Release();
	return S_OK;
}

//------------------------------------------------------------------------------


HRESULT APIENTRY hkIDirect3DDevice9::QueryInterface(REFIID riid, LPVOID *ppvObj) 
{
	//Attempt to cover tracks
	RetourFunc(( BYTE* )GetProcAddress( LoadLibrary( "d3d9.dll" ), "Direct3DCreate9" ), (BYTE *)or1_Direct3DCreate9, 5);
	return or_IDirect3DDevice9->QueryInterface(riid, ppvObj);
}

ULONG APIENTRY hkIDirect3DDevice9::AddRef() 
{
	return or_IDirect3DDevice9->AddRef();
}

HRESULT APIENTRY hkIDirect3DDevice9::BeginScene() 
{
	static bool DoOnce = false;
	if(!DoOnce)
	{
		DoOnce = true;
		pFont = new CFontEngine();
			
		D3DXFONT_DESC pDesc;

		pDesc.Height			= 18;
		pDesc.Width				= 0;
		pDesc.Weight			= FW_BOLD;
		pDesc.MipLevels			= 1;
		pDesc.Italic			= FALSE;
		pDesc.CharSet			= DEFAULT_CHARSET;
		pDesc.OutputPrecision	= OUT_DEFAULT_PRECIS;
		pDesc.Quality			= ANTIALIASED_QUALITY;
		pDesc.PitchAndFamily	= DEFAULT_PITCH | FF_DONTCARE;
		
		strcpy( pDesc.FaceName, "Arial" );

		pFont->Initialize(pDesc, D3DCOLOR_XRGB( 255, 255, 255 ));
	}

	return or_IDirect3DDevice9->BeginScene();
}

HRESULT APIENTRY hkIDirect3DDevice9::BeginStateBlock() 
{
	return or_IDirect3DDevice9->BeginStateBlock();
}

HRESULT APIENTRY hkIDirect3DDevice9::Clear(DWORD Count, CONST D3DRECT *pRects, DWORD Flags, D3DCOLOR Color, float Z, DWORD Stencil) 
{
	return or_IDirect3DDevice9->Clear(Count, pRects, Flags, Color, Z, Stencil);
}

HRESULT APIENTRY hkIDirect3DDevice9::ColorFill(IDirect3DSurface9* pSurface,CONST RECT* pRect, D3DCOLOR color) 
{	
	return or_IDirect3DDevice9->ColorFill(pSurface,pRect,color);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateAdditionalSwapChain(D3DPRESENT_PARAMETERS *pPresentationParameters, IDirect3DSwapChain9 **ppSwapChain) 
{
	return or_IDirect3DDevice9->CreateAdditionalSwapChain(pPresentationParameters, ppSwapChain);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateCubeTexture(UINT EdgeLength,UINT Levels,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DCubeTexture9** ppCubeTexture,HANDLE* pSharedHandle) 
{
	return or_IDirect3DDevice9->CreateCubeTexture(EdgeLength, Levels, Usage, Format, Pool, ppCubeTexture,pSharedHandle);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateDepthStencilSurface(UINT Width,UINT Height,D3DFORMAT Format,D3DMULTISAMPLE_TYPE MultiSample,DWORD MultisampleQuality,BOOL Discard,IDirect3DSurface9** ppSurface,HANDLE* pSharedHandle) 
{
	return or_IDirect3DDevice9->CreateDepthStencilSurface(Width, Height, Format, MultiSample, MultisampleQuality,Discard,ppSurface, pSharedHandle);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateIndexBuffer(UINT Length,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DIndexBuffer9** ppIndexBuffer,HANDLE* pSharedHandle) 
{
	//if( ( Usage & D3DUSAGE_WRITEONLY ) == D3DUSAGE_WRITEONLY )
	//	Usage -= D3DUSAGE_WRITEONLY; 

	return or_IDirect3DDevice9->CreateIndexBuffer(Length, Usage, Format, Pool, ppIndexBuffer,pSharedHandle);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateOffscreenPlainSurface(UINT Width,UINT Height,D3DFORMAT Format,D3DPOOL Pool,IDirect3DSurface9** ppSurface,HANDLE* pSharedHandle) 
{
	return or_IDirect3DDevice9->CreateOffscreenPlainSurface(Width,Height,Format,Pool,ppSurface,pSharedHandle);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreatePixelShader(CONST DWORD* pFunction,IDirect3DPixelShader9** ppShader) 
{
	return or_IDirect3DDevice9->CreatePixelShader(pFunction, ppShader);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateQuery(D3DQUERYTYPE Type,IDirect3DQuery9** ppQuery) 
{
	return or_IDirect3DDevice9->CreateQuery(Type,ppQuery);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateRenderTarget(UINT Width,UINT Height,D3DFORMAT Format,D3DMULTISAMPLE_TYPE MultiSample,DWORD MultisampleQuality,BOOL Lockable,IDirect3DSurface9** ppSurface,HANDLE* pSharedHandle) 
{
	return or_IDirect3DDevice9->CreateRenderTarget(Width, Height, Format, MultiSample,MultisampleQuality, Lockable, ppSurface,pSharedHandle);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateStateBlock(D3DSTATEBLOCKTYPE Type,IDirect3DStateBlock9** ppSB) 
{
	return or_IDirect3DDevice9->CreateStateBlock(Type, ppSB);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateTexture(UINT Width,UINT Height,UINT Levels,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DTexture9** ppTexture,HANDLE* pSharedHandle) 
{ 
	HRESULT hRetVal = NULL;	

	hRetVal = or_IDirect3DDevice9->CreateTexture( Width, Height, Levels, Usage, Format, Pool, ppTexture, pSharedHandle );

	if(hRetVal == D3D_OK)
	{
		hkIDirect3DTexture9 *hk_IDirect3DTexture9 = new hkIDirect3DTexture9;
		hk_IDirect3DTexture9->pD3DTexture9 = *ppTexture;

		//Add texture
		hk_IDirect3DTexture9->Texture.orTexture = *ppTexture;
		hk_IDirect3DTexture9->Texture.height = Height;
		hk_IDirect3DTexture9->Texture.width = Width;
		hk_IDirect3DTexture9->Texture.levels = Levels;
		hk_IDirect3DTexture9->Texture.format= Format;
		hk_IDirect3DTexture9->Texture.crc32 = 0;
		hk_IDirect3DTexture9->Texture.numTexture = g_numTextures;
		g_numTextures++;

	//	static char Buffer[256];
//		sprintf(Buffer, "Format: %x", hk_IDirect3DTexture9->Texture.format);
	//	Log(Buffer);
		*ppTexture = (IDirect3DTexture9 *)hk_IDirect3DTexture9;
	}
	

	

	return hRetVal;
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateVertexBuffer(UINT Length,DWORD Usage,DWORD FVF,D3DPOOL Pool,IDirect3DVertexBuffer9** ppVertexBuffer,HANDLE* pSharedHandle) 
{
	if( ( Usage & D3DUSAGE_WRITEONLY ) == D3DUSAGE_WRITEONLY )
		Usage -= D3DUSAGE_WRITEONLY; 


	return or_IDirect3DDevice9->CreateVertexBuffer(Length, Usage, FVF, Pool, ppVertexBuffer,pSharedHandle);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateVertexDeclaration(CONST D3DVERTEXELEMENT9* pVertexElements,IDirect3DVertexDeclaration9** ppDecl) 
{
	return or_IDirect3DDevice9->CreateVertexDeclaration(pVertexElements,ppDecl);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateVertexShader(CONST DWORD* pFunction,IDirect3DVertexShader9** ppShader) 
{
	return or_IDirect3DDevice9->CreateVertexShader(pFunction, ppShader);
}

HRESULT APIENTRY hkIDirect3DDevice9::CreateVolumeTexture(UINT Width,UINT Height,UINT Depth,UINT Levels,DWORD Usage,D3DFORMAT Format,D3DPOOL Pool,IDirect3DVolumeTexture9** ppVolumeTexture,HANDLE* pSharedHandle) 
{
	return or_IDirect3DDevice9->CreateVolumeTexture(Width, Height, Depth, Levels, Usage, Format, Pool, ppVolumeTexture,pSharedHandle);
}

HRESULT APIENTRY hkIDirect3DDevice9::DeletePatch(UINT Handle) 
{
	return or_IDirect3DDevice9->DeletePatch(Handle);
}

HRESULT APIENTRY hkIDirect3DDevice9::DrawIndexedPrimitive(D3DPRIMITIVETYPE Type,INT BaseVertexIndex,UINT MinVertexIndex,UINT NumVertices,UINT startIndex,UINT primCount) 
{
	static DWORD oldTime =  NULL;
	static DWORD newTime = timeGetTime();
	
	if(GetAsyncKeyState(VK_F9) & 0x8000)
	{
		oldTime = timeGetTime();
		if((oldTime - newTime) > 500)
		{
			newTime = timeGetTime();
			g_numTexture--;
		}
		
		if(g_numTexture <= 0)
			g_numTexture = 0;
		if(g_numTexture >= g_numTextures)
			g_numTexture = g_numTextures;
	}
	if(GetAsyncKeyState(VK_F10) & 0x8000)
	{
		oldTime = timeGetTime();
		if((oldTime - newTime) > 500)
		{
			newTime = timeGetTime();
			g_numTexture++;
		}
		
		if(g_numTexture <= 0)
			g_numTexture = 0;
		if(g_numTexture >= g_numTextures)
			g_numTexture = g_numTextures;
	}

	if(GetAsyncKeyState(VK_INSERT) & 0x8000)
	{
		oldTime = timeGetTime();
		if((oldTime - newTime) > 10)
		{
			newTime = timeGetTime();
			g_numTexture++;
		}
		
		if(g_numTexture <= 0)
			g_numTexture = 0;
		if(g_numTexture >= g_numTextures)
			g_numTexture = g_numTextures;
	}

	if(GetAsyncKeyState(VK_DELETE) & 0x8000)
	{
		oldTime = timeGetTime();
		if((oldTime - newTime) > 10)
		{
			newTime = timeGetTime();
			g_numTexture--;
		}
		
		if(g_numTexture <= 0)
			g_numTexture = 0;
		if(g_numTexture >= g_numTextures)
			g_numTexture = g_numTextures;
	}
	if(GetAsyncKeyState(VK_F11) & 0x8000)
	{
		hackOn = true;
	}

	timer = timeGetTime();

	if(hackOn && (cur_texture != NULL) && ((cur_texture->Texture.crc32 == 3542133160) || (cur_texture->Texture.crc32 == 2725723867)))
	{
		or_IDirect3DDevice9->SetTexture(0, texBlue);
		or_IDirect3DDevice9->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );

		or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );
		or_IDirect3DDevice9->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
		or_IDirect3DDevice9->SetTexture(0, texRed);
		return or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	}//opfor
	else if(hackOn && (cur_texture != NULL) && ((cur_texture->Texture.crc32 == 621949089) || (cur_texture->Texture.crc32 == 2126669994)))
	{
		or_IDirect3DDevice9->SetTexture(0, texGreen);
		or_IDirect3DDevice9->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );

		or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );
		or_IDirect3DDevice9->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
		or_IDirect3DDevice9->SetTexture(0, texYellow);
		return or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	}//sas
	else if(hackOn && (cur_texture != NULL) && ((cur_texture->Texture.crc32 == 2158729783) || (cur_texture->Texture.crc32 == 3049475070)))
	{
		or_IDirect3DDevice9->SetTexture(0, texBlue);
		or_IDirect3DDevice9->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );

		or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );
		or_IDirect3DDevice9->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
		or_IDirect3DDevice9->SetTexture(0, texRed);
		return or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	}//funny name
	else if(hackOn && (cur_texture != NULL) && ((cur_texture->Texture.crc32 == 1923944584) || (cur_texture->Texture.crc32 == 1104654782)))
	{
		or_IDirect3DDevice9->SetTexture(0, texGreen);
		or_IDirect3DDevice9->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );

		or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	
		or_IDirect3DDevice9->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );
		or_IDirect3DDevice9->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
		or_IDirect3DDevice9->SetTexture(0, texYellow);
		return or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	}
	//SAS  4157598617    2158729783l 3049475070l
	//othr 1031238769 hand: 2917224912  1923944584l
	

	HRESULT hResult = or_IDirect3DDevice9->DrawIndexedPrimitive(Type,BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
	
	or_IDirect3DDevice9->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID );
	return hResult;

}

HRESULT APIENTRY hkIDirect3DDevice9::DrawIndexedPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType, UINT MinIndex, UINT NumVertices, UINT PrimitiveCount, CONST void *pIndexData, D3DFORMAT IndexDataFormat, CONST void *pVertexStreamZeroData, UINT VertexStreamZeroStride) 
{	
	return or_IDirect3DDevice9->DrawIndexedPrimitiveUP( PrimitiveType, MinIndex, NumVertices, PrimitiveCount, pIndexData, IndexDataFormat, pVertexStreamZeroData, VertexStreamZeroStride );
}

HRESULT APIENTRY hkIDirect3DDevice9::DrawPrimitive(D3DPRIMITIVETYPE PrimitiveType, UINT StartVertex, UINT PrimitiveCount) 
{
	return or_IDirect3DDevice9->DrawPrimitive( PrimitiveType, StartVertex, PrimitiveCount );
}

HRESULT APIENTRY hkIDirect3DDevice9::DrawPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType, UINT PrimitiveCount, CONST void *pVertexStreamZeroData, UINT VertexStreamZeroStride) 
{
	return or_IDirect3DDevice9->DrawPrimitiveUP(PrimitiveType, PrimitiveCount, pVertexStreamZeroData, VertexStreamZeroStride);
}

HRESULT APIENTRY hkIDirect3DDevice9::DrawRectPatch(UINT Handle, CONST float *pNumSegs, CONST D3DRECTPATCH_INFO *pRectPatchInfo) 
{
	return or_IDirect3DDevice9->DrawRectPatch(Handle, pNumSegs, pRectPatchInfo);
}

HRESULT APIENTRY hkIDirect3DDevice9::DrawTriPatch(UINT Handle, CONST float *pNumSegs, CONST D3DTRIPATCH_INFO *pTriPatchInfo)
{
	return or_IDirect3DDevice9->DrawTriPatch(Handle, pNumSegs, pTriPatchInfo);
}

HRESULT APIENTRY hkIDirect3DDevice9::EndScene()
{	
	sprintf(g_Buffer, "CurrentTexture: %d TotalTextures: %d", g_numTexture, g_numTextures);
	pFont->DrawText(g_Buffer, 5, 10);

	return or_IDirect3DDevice9->EndScene();
}

HRESULT APIENTRY hkIDirect3DDevice9::EndStateBlock(IDirect3DStateBlock9** ppSB) 
{
	return or_IDirect3DDevice9->EndStateBlock(ppSB);
}

HRESULT APIENTRY hkIDirect3DDevice9::EvictManagedResources() 
{
	return or_IDirect3DDevice9->EvictManagedResources();
}

UINT APIENTRY hkIDirect3DDevice9::GetAvailableTextureMem() 
{
	return or_IDirect3DDevice9->GetAvailableTextureMem();
}

HRESULT APIENTRY hkIDirect3DDevice9::GetBackBuffer(UINT iSwapChain,UINT iBackBuffer,D3DBACKBUFFER_TYPE Type,IDirect3DSurface9** ppBackBuffer) 
{
	return or_IDirect3DDevice9->GetBackBuffer(iSwapChain,iBackBuffer, Type, ppBackBuffer);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetClipPlane(DWORD Index, float *pPlane) 
{
	return or_IDirect3DDevice9->GetClipPlane(Index, pPlane);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetClipStatus(D3DCLIPSTATUS9 *pClipStatus) 
{
	return or_IDirect3DDevice9->GetClipStatus(pClipStatus);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetCreationParameters(D3DDEVICE_CREATION_PARAMETERS *pParameters) 
{
	return or_IDirect3DDevice9->GetCreationParameters(pParameters);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetCurrentTexturePalette(UINT *pPaletteNumber)
{
	return or_IDirect3DDevice9->GetCurrentTexturePalette(pPaletteNumber);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetDepthStencilSurface(IDirect3DSurface9 **ppZStencilSurface) 
{
	return or_IDirect3DDevice9->GetDepthStencilSurface(ppZStencilSurface);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetDeviceCaps(D3DCAPS9 *pCaps) 
{
	return or_IDirect3DDevice9->GetDeviceCaps(pCaps);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetDirect3D(IDirect3D9 **ppD3D9) 
{
	HRESULT hRet = or_IDirect3DDevice9->GetDirect3D(ppD3D9);
	*ppD3D9 = Handle;
	return hRet;
}

HRESULT APIENTRY hkIDirect3DDevice9::GetDisplayMode(UINT iSwapChain,D3DDISPLAYMODE* pMode) 
{
	return or_IDirect3DDevice9->GetDisplayMode(iSwapChain,pMode);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetFrontBufferData(UINT iSwapChain,IDirect3DSurface9* pDestSurface) 
{
	return or_IDirect3DDevice9->GetFrontBufferData(iSwapChain,pDestSurface);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetFVF(DWORD* pFVF) 
{
	return or_IDirect3DDevice9->GetFVF(pFVF);
}

void APIENTRY hkIDirect3DDevice9::GetGammaRamp(UINT iSwapChain,D3DGAMMARAMP* pRamp) 
{
	or_IDirect3DDevice9->GetGammaRamp(iSwapChain,pRamp);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetIndices(IDirect3DIndexBuffer9** ppIndexData) 
{
	return or_IDirect3DDevice9->GetIndices(ppIndexData);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetLight(DWORD Index, D3DLIGHT9 *pLight) 
{
	return or_IDirect3DDevice9->GetLight(Index, pLight);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetLightEnable(DWORD Index, BOOL *pEnable) 
{
	return or_IDirect3DDevice9->GetLightEnable(Index, pEnable);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetMaterial(D3DMATERIAL9 *pMaterial) 
{
	return or_IDirect3DDevice9->GetMaterial(pMaterial);
}

float APIENTRY hkIDirect3DDevice9::GetNPatchMode() 
{
	return or_IDirect3DDevice9->GetNPatchMode();
}

unsigned int APIENTRY hkIDirect3DDevice9::GetNumberOfSwapChains() 
{
	return or_IDirect3DDevice9->GetNumberOfSwapChains();
}

HRESULT APIENTRY hkIDirect3DDevice9::GetPaletteEntries(UINT PaletteNumber, PALETTEENTRY *pEntries)
{
	return or_IDirect3DDevice9->GetPaletteEntries(PaletteNumber, pEntries);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetPixelShader(IDirect3DPixelShader9** ppShader) 
{
	return or_IDirect3DDevice9->GetPixelShader(ppShader);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetPixelShaderConstantB(UINT StartRegister,BOOL* pConstantData,UINT BoolCount) 
{
	return or_IDirect3DDevice9->GetPixelShaderConstantB(StartRegister,pConstantData,BoolCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetPixelShaderConstantF(UINT StartRegister,float* pConstantData,UINT Vector4fCount) 
{
	return or_IDirect3DDevice9->GetPixelShaderConstantF(StartRegister,pConstantData,Vector4fCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetPixelShaderConstantI(UINT StartRegister,int* pConstantData,UINT Vector4iCount)
{
	return or_IDirect3DDevice9->GetPixelShaderConstantI(StartRegister,pConstantData,Vector4iCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetRasterStatus(UINT iSwapChain,D3DRASTER_STATUS* pRasterStatus) 
{
	return or_IDirect3DDevice9->GetRasterStatus(iSwapChain,pRasterStatus);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetRenderState(D3DRENDERSTATETYPE State, DWORD *pValue) 
{
	return or_IDirect3DDevice9->GetRenderState(State, pValue);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetRenderTarget(DWORD RenderTargetIndex,IDirect3DSurface9** ppRenderTarget) 
{
	return or_IDirect3DDevice9->GetRenderTarget(RenderTargetIndex,ppRenderTarget);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetRenderTargetData(IDirect3DSurface9* pRenderTarget,IDirect3DSurface9* pDestSurface) 
{
	return or_IDirect3DDevice9->GetRenderTargetData(pRenderTarget,pDestSurface);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetSamplerState(DWORD Sampler,D3DSAMPLERSTATETYPE Type,DWORD* pValue) 
{
	return or_IDirect3DDevice9->GetSamplerState(Sampler,Type,pValue);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetScissorRect(RECT* pRect) 
{
	return or_IDirect3DDevice9->GetScissorRect(pRect);
}

BOOL APIENTRY hkIDirect3DDevice9::GetSoftwareVertexProcessing() 
{
	return or_IDirect3DDevice9->GetSoftwareVertexProcessing();
}

HRESULT APIENTRY hkIDirect3DDevice9::GetStreamSource(UINT StreamNumber,IDirect3DVertexBuffer9** ppStreamData,UINT* OffsetInBytes,UINT* pStride) 
{
	return or_IDirect3DDevice9->GetStreamSource(StreamNumber, ppStreamData,OffsetInBytes, pStride);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetStreamSourceFreq(UINT StreamNumber,UINT* Divider) 
{
	return or_IDirect3DDevice9->GetStreamSourceFreq(StreamNumber,Divider);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetSwapChain(UINT iSwapChain,IDirect3DSwapChain9** pSwapChain)
{
	return or_IDirect3DDevice9->GetSwapChain(iSwapChain,pSwapChain);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetTexture(DWORD Stage, IDirect3DBaseTexture9 **ppTexture) 
{
	return or_IDirect3DDevice9->GetTexture(Stage, ppTexture);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetTextureStageState(DWORD Stage, D3DTEXTURESTAGESTATETYPE Type, DWORD *pValue) 
{
	return or_IDirect3DDevice9->GetTextureStageState(Stage, Type, pValue);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetTransform(D3DTRANSFORMSTATETYPE State, D3DMATRIX *pMatrix) 
{
	return or_IDirect3DDevice9->GetTransform(State, pMatrix);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetVertexDeclaration(IDirect3DVertexDeclaration9** ppDecl) 
{
	return or_IDirect3DDevice9->GetVertexDeclaration(ppDecl);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetVertexShader(IDirect3DVertexShader9** ppShader) 
{
	return or_IDirect3DDevice9->GetVertexShader(ppShader);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetVertexShaderConstantB(UINT StartRegister,BOOL* pConstantData,UINT BoolCount)
{
	return or_IDirect3DDevice9->GetVertexShaderConstantB(StartRegister,pConstantData,BoolCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetVertexShaderConstantF(UINT StartRegister,float* pConstantData,UINT Vector4fCount) 
{
	return or_IDirect3DDevice9->GetVertexShaderConstantF(StartRegister,pConstantData,Vector4fCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetVertexShaderConstantI(UINT StartRegister,int* pConstantData,UINT Vector4iCount)
{
	return or_IDirect3DDevice9->GetVertexShaderConstantI(StartRegister,pConstantData,Vector4iCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::GetViewport(D3DVIEWPORT9 *pViewport) 
{
	return or_IDirect3DDevice9->GetViewport(pViewport);
}

HRESULT APIENTRY hkIDirect3DDevice9::LightEnable(DWORD LightIndex, BOOL bEnable) 
{
	return or_IDirect3DDevice9->LightEnable(LightIndex, bEnable);
}

HRESULT APIENTRY hkIDirect3DDevice9::MultiplyTransform(D3DTRANSFORMSTATETYPE State, CONST D3DMATRIX *pMatrix) 
{
	return or_IDirect3DDevice9->MultiplyTransform(State, pMatrix);
}

HRESULT APIENTRY hkIDirect3DDevice9::Present(CONST RECT *pSourceRect, CONST RECT *pDestRect, HWND hDestWindowOverride, CONST RGNDATA *pDirtyRegion) 
{	
	return or_IDirect3DDevice9->Present(pSourceRect, pDestRect, hDestWindowOverride, pDirtyRegion);
}

HRESULT APIENTRY hkIDirect3DDevice9::ProcessVertices(UINT SrcStartIndex,UINT DestIndex,UINT VertexCount,IDirect3DVertexBuffer9* pDestBuffer,IDirect3DVertexDeclaration9* pVertexDecl,DWORD Flags) 
{
	return or_IDirect3DDevice9->ProcessVertices(SrcStartIndex, DestIndex, VertexCount, pDestBuffer,pVertexDecl, Flags);
}

ULONG APIENTRY hkIDirect3DDevice9::Release() 
{
	or_IDirect3DDevice9->Release();

	return S_OK;
}

HRESULT APIENTRY hkIDirect3DDevice9::Reset(D3DPRESENT_PARAMETERS *pPresentationParameters) 
{
	return or_IDirect3DDevice9->Reset(pPresentationParameters);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetClipPlane(DWORD Index, CONST float *pPlane) 
{
	return or_IDirect3DDevice9->SetClipPlane(Index, pPlane);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetClipStatus(CONST D3DCLIPSTATUS9 *pClipStatus) 
{
	return or_IDirect3DDevice9->SetClipStatus(pClipStatus);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetCurrentTexturePalette(UINT PaletteNumber) 
{
	return or_IDirect3DDevice9->SetCurrentTexturePalette(PaletteNumber);
}

void APIENTRY hkIDirect3DDevice9::SetCursorPosition(int X, int Y, DWORD Flags) 
{
	or_IDirect3DDevice9->SetCursorPosition(X, Y, Flags);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetCursorProperties(UINT XHotSpot, UINT YHotSpot, IDirect3DSurface9 *pCursorBitmap) 
{
	return or_IDirect3DDevice9->SetCursorProperties(XHotSpot, YHotSpot, pCursorBitmap);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetDepthStencilSurface(IDirect3DSurface9* pNewZStencil) 
{
	return or_IDirect3DDevice9->SetDepthStencilSurface(pNewZStencil);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetDialogBoxMode(BOOL bEnableDialogs) 
{
	return or_IDirect3DDevice9->SetDialogBoxMode(bEnableDialogs);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetFVF(DWORD FVF) 
{
	return or_IDirect3DDevice9->SetFVF(FVF);
}

void APIENTRY hkIDirect3DDevice9::SetGammaRamp(UINT iSwapChain,DWORD Flags,CONST D3DGAMMARAMP* pRamp)
{
	or_IDirect3DDevice9->SetGammaRamp(iSwapChain,Flags, pRamp);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetIndices(IDirect3DIndexBuffer9* pIndexData) 
{
	return or_IDirect3DDevice9->SetIndices(pIndexData);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetLight(DWORD Index, CONST D3DLIGHT9 *pLight) 
{
	return or_IDirect3DDevice9->SetLight(Index, pLight);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetMaterial(CONST D3DMATERIAL9 *pMaterial) 
{	
	return or_IDirect3DDevice9->SetMaterial(pMaterial);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetNPatchMode(float nSegments) 
{	
	return or_IDirect3DDevice9->SetNPatchMode(nSegments);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetPaletteEntries(UINT PaletteNumber, CONST PALETTEENTRY *pEntries) 
{
	return or_IDirect3DDevice9->SetPaletteEntries(PaletteNumber, pEntries);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetPixelShader(IDirect3DPixelShader9* pShader) 
{
	return or_IDirect3DDevice9->SetPixelShader(pShader);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetPixelShaderConstantB(UINT StartRegister,CONST BOOL* pConstantData,UINT  BoolCount) 
{
	return or_IDirect3DDevice9->SetPixelShaderConstantB(StartRegister,pConstantData,BoolCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetPixelShaderConstantF(UINT StartRegister,CONST float* pConstantData,UINT Vector4fCount) 
{
	return or_IDirect3DDevice9->SetPixelShaderConstantF(StartRegister,pConstantData,Vector4fCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetPixelShaderConstantI(UINT StartRegister,CONST int* pConstantData,UINT Vector4iCount) 
{
	return or_IDirect3DDevice9->SetPixelShaderConstantI(StartRegister,pConstantData,Vector4iCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetRenderState(D3DRENDERSTATETYPE State, DWORD Value) 
{
	return or_IDirect3DDevice9->SetRenderState(State, Value);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetRenderTarget(DWORD RenderTargetIndex, IDirect3DSurface9* pRenderTarget) 
{
	return or_IDirect3DDevice9->SetRenderTarget(RenderTargetIndex,pRenderTarget);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetSamplerState(DWORD Sampler,D3DSAMPLERSTATETYPE Type,DWORD Value) 
{
	return or_IDirect3DDevice9->SetSamplerState(Sampler,Type,Value);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetScissorRect(CONST RECT* pRect) 
{
	return or_IDirect3DDevice9->SetScissorRect(pRect);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetSoftwareVertexProcessing(BOOL bSoftware) 
{
	return or_IDirect3DDevice9->SetSoftwareVertexProcessing(bSoftware);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetStreamSource(UINT StreamNumber,IDirect3DVertexBuffer9* pStreamData,UINT OffsetInBytes,UINT Stride) 
{
	return or_IDirect3DDevice9->SetStreamSource(StreamNumber, pStreamData,OffsetInBytes, Stride);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetStreamSourceFreq(UINT StreamNumber,UINT Divider)
{	
	return or_IDirect3DDevice9->SetStreamSourceFreq(StreamNumber,Divider);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetTexture(DWORD Stage, IDirect3DBaseTexture9 *pTexture) 
{
	static char Buffer[256];
	hkIDirect3DTexture9 *pD3D9Tex = NULL;

	try
	{
        IDirect3DDevice9 *iDevTmp = NULL;
		cur_texture = (hkIDirect3DTexture9 *)pTexture;
		if(pTexture != NULL && ((hkIDirect3DTexture9*)(pTexture))->GetDevice(&iDevTmp) == D3D_OK)
		{
			if( iDevTmp == this)
			{
				pD3D9Tex = (hkIDirect3DTexture9*)pTexture;
				
				if(!pD3D9Tex->Texture.crc32)
				{
					static CDynamicCrc32 Checksum;
	
					D3DLOCKED_RECT pLockedRect;	
					pD3D9Tex->LockRect( 0, &pLockedRect, NULL, D3DLOCK_READONLY );	

					if(&pLockedRect && pLockedRect.pBits)
					{
						switch(pD3D9Tex->Texture.format)
						{
							//calls failing!!! check pLockedRect;
							case 0x35545844: //comprssed texture 1
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits,  0.5 * pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
								//sprintf(Buffer, "texture1: TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;

							case 0x33545844:
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits,  1 * pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
					
								/*sprintf(Buffer, "0x%x", pD3D9Tex);
								if(strcmp(Buffer, "0x200fb330") == 0)
								{
									if(!pD3D9Tex->Texture.crc32)
										pD3D9Tex->Texture.crc32 = 1;
									Log("WTF359u4u9u9454");
								}	*/
								
								//sprintf(Buffer, "texture2: TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;

							case 0x31545844:
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits,  0.5 * pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
							//	sprintf(Buffer, "texture3: TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;

							case 0x33:
								//Log("33");
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits, 4 * pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
								//sprintf(Buffer, "33/31/32: TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;

							case 0x31:
							//	Log("31");
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits, 4 * pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
							//	sprintf(Buffer, "33/31/32: TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;

							case 0x32:
							//	Log("32");
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits, 1 * pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
							//	sprintf(Buffer, "33/31/32: TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;

							
							case 0x15:
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits, pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
							//	sprintf(Buffer, "0x15 : TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
						//		Log(Buffer);
							break;
							

							case 0x16:
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits, pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
							//	sprintf(Buffer, "0x16 : TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;

							case 0x72:
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits, pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
							//	sprintf(Buffer, "0x72 : TextureHeight: %d  TextureWidth: %d", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width);
							//	Log(Buffer);
							break;


							default:
							//	Log("8");
								pD3D9Tex->Texture.crc32 = Checksum.GetCrc32((BYTE *)pLockedRect.pBits, pD3D9Tex->Texture.height * pD3D9Tex->Texture.width);
								//sprintf(Buffer, "default44544444 : TextureHeight: %d  TextureWidth: %d    Textureformat: %x", pD3D9Tex->Texture.height, pD3D9Tex->Texture.width, pD3D9Tex->Texture.format);
								//Log(Buffer);
							break;
						}
		
						sprintf(Buffer, "Crc32: 0x%x  texture : 0x%x", pD3D9Tex->Texture.crc32, pD3D9Tex);
						Log(Buffer);
					}
					pD3D9Tex->UnlockRect(0);
		
					return or_IDirect3DDevice9->SetTexture(Stage, pD3D9Tex->pD3DTexture9 );
				}
				else
				{
					for(int x = 0; x < g_numTextures; x++)
					{
						if(cur_texture->Texture.numTexture == g_numTexture)
						{
							or_IDirect3DDevice9->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );
						
							if(GetAsyncKeyState(VK_END) & 0x8000)
							{
								sprintf(g_Buffer, "Selected texture: 0x%x Selected CRC: 0x%x Selected DWORD CRC: %u CRC32: %ul", pD3D9Tex, pD3D9Tex->Texture.crc32, pD3D9Tex, pD3D9Tex->Texture.crc32, pD3D9Tex->Texture.crc32);
								Log(g_Buffer);
							}
							return or_IDirect3DDevice9->SetTexture(0, texBlue);
							break;
						}
					}
				}

				return or_IDirect3DDevice9->SetTexture(Stage, pD3D9Tex->pD3DTexture9 );
			}
				
		}
		
	
	}
	catch( ... )
	{
		sprintf(Buffer, "texture : 0x%x", pD3D9Tex);
		Log(Buffer);
		Log( "Exception Caught in SetTexture!" );
	}

	return or_IDirect3DDevice9->SetTexture(Stage, pTexture);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetTextureStageState(DWORD Stage, D3DTEXTURESTAGESTATETYPE Type, DWORD Value) 
{
	return or_IDirect3DDevice9->SetTextureStageState(Stage, Type, Value);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetTransform(D3DTRANSFORMSTATETYPE State, CONST D3DMATRIX *pMatrix) 
{
	return or_IDirect3DDevice9->SetTransform(State, pMatrix);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetVertexDeclaration(IDirect3DVertexDeclaration9* pDecl) 
{
	return or_IDirect3DDevice9->SetVertexDeclaration(pDecl);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetVertexShader(IDirect3DVertexShader9* pShader) 
{
	return or_IDirect3DDevice9->SetVertexShader(pShader);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetVertexShaderConstantB(UINT StartRegister,CONST BOOL* pConstantData,UINT  BoolCount) 
{
	return or_IDirect3DDevice9->SetVertexShaderConstantB(StartRegister,pConstantData,BoolCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetVertexShaderConstantF(UINT StartRegister,CONST float* pConstantData,UINT Vector4fCount) 
{
	return or_IDirect3DDevice9->SetVertexShaderConstantF( StartRegister, pConstantData, Vector4fCount );
}

HRESULT APIENTRY hkIDirect3DDevice9::SetVertexShaderConstantI(UINT StartRegister,CONST int* pConstantData,UINT Vector4iCount) 
{
	return or_IDirect3DDevice9->SetVertexShaderConstantI(StartRegister,pConstantData,Vector4iCount);
}

HRESULT APIENTRY hkIDirect3DDevice9::SetViewport(CONST D3DVIEWPORT9 *pViewport) 
{
	return or_IDirect3DDevice9->SetViewport( pViewport );
}

BOOL APIENTRY hkIDirect3DDevice9::ShowCursor(BOOL bShow) 
{
	return or_IDirect3DDevice9->ShowCursor(bShow);
}

HRESULT APIENTRY hkIDirect3DDevice9::StretchRect(IDirect3DSurface9* pSourceSurface,CONST RECT* pSourceRect,IDirect3DSurface9* pDestSurface,CONST RECT* pDestRect,D3DTEXTUREFILTERTYPE Filter) 
{
	return or_IDirect3DDevice9->StretchRect(pSourceSurface,pSourceRect,pDestSurface,pDestRect,Filter);
}

HRESULT APIENTRY hkIDirect3DDevice9::TestCooperativeLevel() 
{
	return or_IDirect3DDevice9->TestCooperativeLevel();
}

HRESULT APIENTRY hkIDirect3DDevice9::UpdateSurface(IDirect3DSurface9* pSourceSurface,CONST RECT* pSourceRect,IDirect3DSurface9* pDestinationSurface,CONST POINT* pDestPoint) 
{
	return or_IDirect3DDevice9->UpdateSurface(pSourceSurface,pSourceRect,pDestinationSurface,pDestPoint);
}

HRESULT APIENTRY hkIDirect3DDevice9::UpdateTexture(IDirect3DBaseTexture9 *pSourceTexture, IDirect3DBaseTexture9 *pDestinationTexture) 
{
	return or_IDirect3DDevice9->UpdateTexture(pSourceTexture, pDestinationTexture);
}

HRESULT APIENTRY hkIDirect3DDevice9::ValidateDevice(DWORD *pNumPasses) 
{
	return or_IDirect3DDevice9->ValidateDevice(pNumPasses);
}


//------------------------------------------------texture

HRESULT	APIENTRY hkIDirect3DTexture9::QueryInterface(REFIID iid, void ** ppvObject)
{
	HRESULT hResult = pD3DTexture9->QueryInterface( iid, ppvObject );

	Log("In Direct3dTexture Query Interface");

	return hResult;
}

ULONG APIENTRY hkIDirect3DTexture9::AddRef( )
{
	return pD3DTexture9->AddRef( );
}

ULONG APIENTRY hkIDirect3DTexture9::Release( )
{
	ULONG uRetVal = pD3DTexture9->Release( ); 
	
//	RemoveTexture( ( DWORD )this );

	return uRetVal;
}

HRESULT APIENTRY hkIDirect3DTexture9::AddDirtyRect(CONST RECT* pDirtyRect)
{
	return pD3DTexture9->AddDirtyRect(pDirtyRect);
}

HRESULT APIENTRY hkIDirect3DTexture9::GetLevelDesc(UINT Level, D3DSURFACE_DESC* pDesc)
{
	return pD3DTexture9->GetLevelDesc(Level, pDesc);
}

HRESULT APIENTRY hkIDirect3DTexture9::GetSurfaceLevel(UINT Level, IDirect3DSurface9** ppSurfaceLevel)
{
	return pD3DTexture9->GetSurfaceLevel(Level, ppSurfaceLevel);
}
HRESULT APIENTRY hkIDirect3DTexture9::LockRect(UINT Level, D3DLOCKED_RECT* pLockedRect, CONST RECT* pRect, DWORD Flags)
{	
	
	HRESULT hResult = pD3DTexture9->LockRect(Level, pLockedRect, pRect, Flags);
	m_rectBackup = pLockedRect;

	return hResult;
}

HRESULT APIENTRY hkIDirect3DTexture9::UnlockRect(UINT Level)
{
	HRESULT hResult = pD3DTexture9->UnlockRect(Level);

	return hResult;
}

HRESULT APIENTRY hkIDirect3DTexture9::GetDevice(IDirect3DDevice9 **ppDevice)
{
	if( ppDevice )
		( *ppDevice ) = hk_IDirect3DDevice9;

	return D3D_OK;
}

HRESULT APIENTRY hkIDirect3DTexture9::SetPrivateData(REFGUID refguid, CONST void* pData, DWORD SizeOfData, DWORD Flags)
{
	return pD3DTexture9->SetPrivateData(refguid, pData, SizeOfData, Flags);
}

HRESULT APIENTRY hkIDirect3DTexture9::GetPrivateData(REFGUID refguid, void* pData, DWORD* pSizeOfData)
{
	return pD3DTexture9->GetPrivateData(refguid, pData, pSizeOfData);
}

HRESULT APIENTRY hkIDirect3DTexture9::FreePrivateData(REFGUID refguid)
{
	return pD3DTexture9->FreePrivateData(refguid);
}

DWORD APIENTRY hkIDirect3DTexture9::SetPriority(DWORD PriorityNew)
{
	return pD3DTexture9->SetPriority(PriorityNew);
}

DWORD APIENTRY hkIDirect3DTexture9::GetPriority()
{
	return pD3DTexture9->GetPriority();
}

void APIENTRY hkIDirect3DTexture9::PreLoad()
{
	pD3DTexture9->PreLoad();
}

D3DRESOURCETYPE APIENTRY hkIDirect3DTexture9::GetType()
{
	return pD3DTexture9->GetType();
}

DWORD APIENTRY hkIDirect3DTexture9::SetLOD(DWORD LODNew)
{
	return pD3DTexture9->SetLOD(LODNew);
}

DWORD APIENTRY hkIDirect3DTexture9::GetLOD()
{
	return pD3DTexture9->GetLOD();
}

DWORD APIENTRY hkIDirect3DTexture9::GetLevelCount()
{
	return pD3DTexture9->GetLevelCount();
}

VOID APIENTRY hkIDirect3DTexture9::GenerateMipSubLevels(VOID)
{
	pD3DTexture9->GenerateMipSubLevels();
}

D3DTEXTUREFILTERTYPE APIENTRY hkIDirect3DTexture9::GetAutoGenFilterType(VOID)
{
	return pD3DTexture9->GetAutoGenFilterType();
}

HRESULT APIENTRY hkIDirect3DTexture9::SetAutoGenFilterType(D3DTEXTUREFILTERTYPE FilterType)
{
	return pD3DTexture9->SetAutoGenFilterType(FilterType);
}


//----------------------------------------------------------

HRESULT __stdcall hkIDirectDraw::QueryInterface(REFIID riid, void ** ppvObject)
{
	Log("1"); return cur_DirectDraw->QueryInterface(riid, ppvObject);
}
ULONG __stdcall hkIDirectDraw::AddRef()
{
	Log("2"); return cur_DirectDraw->AddRef();
}
ULONG __stdcall hkIDirectDraw::Release()
{
	Log("3"); return cur_DirectDraw->Release();
}

/*** IDirectDraw methods ***/
HRESULT __stdcall hkIDirectDraw::Compact()
{
	Log("4"); return cur_DirectDraw->Compact();
}

HRESULT __stdcall hkIDirectDraw::CreateClipper(DWORD a, LPDIRECTDRAWCLIPPER FAR* b, IUnknown FAR * c)
{
	Log("5"); return cur_DirectDraw->CreateClipper(a, b, c);
}

HRESULT __stdcall hkIDirectDraw::CreatePalette(DWORD a, LPPALETTEENTRY b, LPDIRECTDRAWPALETTE FAR* c, IUnknown FAR * d)
{
	Log("6"); return cur_DirectDraw->CreatePalette(a, b, c, d);
}

HRESULT __stdcall hkIDirectDraw::CreateSurface(LPDDSURFACEDESC a, LPDIRECTDRAWSURFACE FAR *b, IUnknown FAR *c)
{
	Log("7"); return cur_DirectDraw->CreateSurface(a, b, c);
}

HRESULT __stdcall hkIDirectDraw::DuplicateSurface(LPDIRECTDRAWSURFACE a, LPDIRECTDRAWSURFACE FAR * b)
{
	Log("8"); return cur_DirectDraw->DuplicateSurface(a, b);
}

HRESULT __stdcall hkIDirectDraw::EnumDisplayModes(DWORD a, LPDDSURFACEDESC b, LPVOID c, LPDDENUMMODESCALLBACK d)
{
	Log("9"); return cur_DirectDraw->EnumDisplayModes(a, b, c, d);
}

HRESULT __stdcall hkIDirectDraw::EnumSurfaces(DWORD a, LPDDSURFACEDESC b, LPVOID c,LPDDENUMSURFACESCALLBACK d)
{
	Log("10"); return cur_DirectDraw->EnumSurfaces(a, b, c, d);
}

HRESULT __stdcall hkIDirectDraw::FlipToGDISurface()
{
	Log("11"); return cur_DirectDraw->FlipToGDISurface();
}

HRESULT __stdcall hkIDirectDraw::GetCaps(LPDDCAPS a, LPDDCAPS b)
{
	Log("12"); return cur_DirectDraw->GetCaps(a, b);
}

HRESULT __stdcall hkIDirectDraw::GetDisplayMode(LPDDSURFACEDESC a)
{
	Log("13"); return cur_DirectDraw->GetDisplayMode(a);
}

HRESULT __stdcall hkIDirectDraw::GetFourCCCodes(LPDWORD a, LPDWORD b)
{
	Log("14"); return cur_DirectDraw->GetFourCCCodes(a, b);
}

HRESULT __stdcall hkIDirectDraw::GetGDISurface(LPDIRECTDRAWSURFACE FAR * a)
{
	Log("15"); return cur_DirectDraw->GetGDISurface(a);
}

HRESULT __stdcall hkIDirectDraw::GetMonitorFrequency(LPDWORD a)
{
	Log("16"); return cur_DirectDraw->GetMonitorFrequency(a);
}

HRESULT __stdcall hkIDirectDraw::GetScanLine(LPDWORD a)
{
	Log("17"); return cur_DirectDraw->GetScanLine(a);
}

HRESULT __stdcall hkIDirectDraw::GetVerticalBlankStatus(LPBOOL a)
{
	Log("18"); return cur_DirectDraw->GetVerticalBlankStatus(a);
}

HRESULT __stdcall hkIDirectDraw::Initialize(GUID FAR * a)
{
	Log("19"); return cur_DirectDraw->Initialize(a);
}

HRESULT __stdcall hkIDirectDraw::RestoreDisplayMode()
{
	Log("20"); return cur_DirectDraw->RestoreDisplayMode();
}

HRESULT __stdcall hkIDirectDraw::SetCooperativeLevel(HWND a, DWORD b)
{
	Log("21"); return cur_DirectDraw->SetCooperativeLevel(a, b);
}

HRESULT __stdcall hkIDirectDraw::SetDisplayMode(DWORD a, DWORD b,DWORD c)
{
	Log("22"); return cur_DirectDraw->SetDisplayMode(a, b, c);
}

HRESULT __stdcall hkIDirectDraw::WaitForVerticalBlank(DWORD a, HANDLE b)
{
	Log("23"); return cur_DirectDraw->WaitForVerticalBlank(a, b);
}

