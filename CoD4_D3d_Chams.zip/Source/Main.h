
#pragma once

#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <d3dx9core.h>
#include <D3dx9tex.h>
#include <ddraw.h>
#include <psapi.h>

#include <iostream>
#include <deque>

#include "detours.h"
#include "Direct3DFunctions.h"
#include "CRC32.h"
#include "Font.h"

#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "Winmm.lib")

using namespace std;

#define D3D_DEBUG_INFO

extern bool hackOn;
extern char g_Buffer[256];
extern void Log(char *Msg, ...);

typedef int (__cdecl *InternalDDC)(int a, IDirectDraw * b, int c, int d, int e);
extern InternalDDC or_ddc;

typedef IDirect3D9 *(APIENTRY *fn_Direct3DCreate9)(UINT);
extern fn_Direct3DCreate9 or_Direct3DCreate9, or1_Direct3DCreate9;

extern DWORD timer;
extern DWORD start;