/********************************************************************
Virtual function table hook mechanism
written by LanceVorgin aka stosw aka like 90 other names
ty to qizmo for helping and uni for owning me
oh and go play in traffic trimbo - real mature eh - I blame the drugs
********************************************************************/

/*
class someinterface {
public:
	virtual void somefunc(char* somearg) = 0;
};

class someclass : public someinterface {
public:
	void somefunc(char* somearg){
		printf("someclass::somefunc: %x %s\n", someval, somearg ? somearg : "NULL");
	}

	int someval;
};


DEFVFUNC(someclass_somefunc, (someclass* pa, char* somearg));

void VFUNC hookedsomefunc(someclass* pa, char* somearg){
	printf("hooked it:  %s\n", somearg ? somearg : "NULL");
	someclass_somefunc(pa, "lol owned");
	printf("leaving hook\n");
}

someclass q;
someclass w;

void main(){
	q.someval = 0xdeadbeef;
	w.someval = 0xc0defeed;

	HOOKVFUNC(&q, 0, someclass_somefunc, hookedsomefunc);
	
	dynamic_cast<someinterface*>(&q)->somefunc("testing"); //forces vtable lookup
	
	someclass_somefunc(&w, "should be codefeed yo");
}
*/

#include "Main.h"

#define ADDRTYPE unsigned long

#define VTBL( classptr ) (*(ADDRTYPE*)classptr)
#define PVFN_( classptr , offset ) (VTBL( classptr ) + offset)
#define VFN_( classptr , offset ) *(ADDRTYPE*)PVFN_( classptr , offset )
#define PVFN( classptr , offset ) PVFN_( classptr , ( offset * sizeof(void*) ) )
#define VFN( classptr , offset ) VFN_( classptr , ( offset * sizeof(void*) ) )

#ifndef __LINUX__

	class CVirtualCallGate {
	public:

		void Build(void* pOrigFunc, void* pNewFunc, void* pOrgFuncCaller){
			m_szGate[0] = \'\x58\';								//pop eax
			m_szGate[1] = \'\x51\';								//push ecx
			m_szGate[2] = \'\x50\';								//push eax
			m_szGate[3] = \'\x68\';								//push u32
			*(ADDRTYPE*)&m_szGate[4] = (ADDRTYPE)pNewFunc;		//  newfunc
			m_szGate[8] = \'\xC3\';								//ret
			
			*(ADDRTYPE*)pOrgFuncCaller = (ADDRTYPE)&m_szGate[9];

			m_szGate[9] = \'\x58\';								//pop eax
			m_szGate[10] = \'\x59\'; 								//pop ecx
			m_szGate[11] = \'\x50\'; 								//push eax
			m_szGate[12] = \'\x68\'; 								//push u32
			*(ADDRTYPE*)&m_szGate[13] = (ADDRTYPE)pOrigFunc;	//  orgfunc
			m_szGate[17] = \'\xC3\';								//ret
		}

		ADDRTYPE Gate(){
			return (ADDRTYPE)&m_szGate[0];
		}

	private:
		char m_szGate[18];
	};

	inline bool DeProtect(void* pMemory, unsigned int uiLen){
		ADDRTYPE dwIDontCare;
		
		return (VirtualProtect(pMemory, uiLen, PAGE_EXECUTE_READWRITE, &dwIDontCare) ? true : false);
	}

	#define VFUNC __stdcall

	#define DEFVFUNC( funcname , returntype , proto ) \
		typedef returntype ( VFUNC * funcname##Func ) proto ; \
		funcname##Func funcname = NULL; \
		CVirtualCallGate funcname##Gate;

	#define HOOKVFUNC( classptr , index , funcname , newfunc ) \
		DeProtect((void*)VTBL( classptr ), ( index * sizeof(void*)) + 4 ); \
		funcname##Gate.Build((void*)VFN( classptr , index ), newfunc , & funcname ); \
		*(ADDRTYPE*)PVFN( classptr , index ) = funcname##Gate.Gate();

#else

	#define VFUNC

	#define DEFVFUNC( funcname , returntype , proto ) \
		typedef returntype ( * funcname##Func ) proto ; \
		funcname##Func funcname = NULL; 

	#define HOOKVFUNC( classptr , index , funcname , newfunc ) \
		funcname = ( funcname##Func )VFN( classptr , index ); \
		*(ADDRTYPE*)PVFN( classptr , index ) = newfunc ;

#endif